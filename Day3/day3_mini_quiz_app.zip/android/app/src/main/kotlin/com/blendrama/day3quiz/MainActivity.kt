package com.blendrama.day3quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
