import 'package:flutter/material.dart';

void main() {
  runApp(const MiniQuizApp());
}

class MiniQuizApp extends StatelessWidget {
  const MiniQuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mini Quiz App',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
      ),
      home: const QuizScreen(),
    );
  }
}

class QuizQuestion {
  final String question;
  final List<String> options;
  final int correctIndex;

  QuizQuestion({
    required this.question,
    required this.options,
    required this.correctIndex,
  });
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  final List<QuizQuestion> questions = [
    QuizQuestion(
      question: 'What is Flutter used for?',
      options: ['Cooking', 'Building apps', 'Editing videos', 'Drawing only'],
      correctIndex: 1,
    ),
    QuizQuestion(
      question: 'Which language is used in Flutter?',
      options: ['Dart', 'Python', 'C only', 'HTML only'],
      correctIndex: 0,
    ),
    QuizQuestion(
      question: 'What does setState do?',
      options: [
        'Deletes the app',
        'Refreshes the UI',
        'Closes Flutter',
        'Changes GitHub branch'
      ],
      correctIndex: 1,
    ),
  ];

  int currentQuestionIndex = 0;
  int score = 0;

  void answerQuestion(int selectedIndex) {
    final currentQuestion = questions[currentQuestionIndex];

    if (selectedIndex == currentQuestion.correctIndex) {
      score++;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Correct answer!'),
          duration: Duration(milliseconds: 700),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Wrong answer!'),
          duration: Duration(milliseconds: 700),
        ),
      );
    }

    if (currentQuestionIndex < questions.length - 1) {
      setState(() {
        currentQuestionIndex++;
      });
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ResultScreen(
            score: score,
            totalQuestions: questions.length,
            onRestart: restartQuiz,
          ),
        ),
      );
    }
  }

  void restartQuiz() {
    setState(() {
      currentQuestionIndex = 0;
      score = 0;
    });

    Navigator.pop(context);
  }

  void showQuestionDetails() {
    final currentQuestion = questions[currentQuestionIndex];

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Question Details'),
          content: Text(
            'Question: ${currentQuestion.question}\n\n'
            'This screen shows details for the selected quiz item.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentQuestion = questions[currentQuestionIndex];

    return Scaffold(
      backgroundColor: Colors.blueGrey[50],
      appBar: AppBar(
        title: const Text('Mini Quiz App'),
        centerTitle: true,
        backgroundColor: Colors.blueGrey,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 500),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Card(
              elevation: 6,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
              ),
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.quiz,
                      size: 60,
                      color: Colors.blueGrey,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Question ${currentQuestionIndex + 1} of ${questions.length}',
                      style: const TextStyle(
                        fontSize: 18,
                        color: Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      currentQuestion.question,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 20),
                    ...currentQuestion.options.asMap().entries.map(
                      (entry) {
                        int index = entry.key;
                        String option = entry.value;

                        return Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 10),
                          child: ElevatedButton(
                            onPressed: () {
                              answerQuestion(index);
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blueGrey,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.all(14),
                            ),
                            child: Text(option),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 10),
                    TextButton.icon(
                      onPressed: showQuestionDetails,
                      icon: const Icon(Icons.info),
                      label: const Text('View Question Details'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final int score;
  final int totalQuestions;
  final VoidCallback onRestart;

  const ResultScreen({
    super.key,
    required this.score,
    required this.totalQuestions,
    required this.onRestart,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[50],
      appBar: AppBar(
        title: const Text('Quiz Result'),
        centerTitle: true,
        backgroundColor: Colors.blueGrey,
      ),
      body: Center(
        child: Card(
          elevation: 6,
          margin: const EdgeInsets.all(20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
          child: Padding(
            padding: const EdgeInsets.all(26),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.emoji_events,
                  size: 70,
                  color: Colors.blueGrey,
                ),
                const SizedBox(height: 15),
                const Text(
                  'Quiz Completed!',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 15),
                Text(
                  'Your score is $score / $totalQuestions',
                  style: const TextStyle(fontSize: 20),
                ),
                const SizedBox(height: 22),
                ElevatedButton(
                  onPressed: onRestart,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueGrey,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 28,
                      vertical: 12,
                    ),
                  ),
                  child: const Text('Restart Quiz'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
