package com.blendrama.day3quiznavigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
