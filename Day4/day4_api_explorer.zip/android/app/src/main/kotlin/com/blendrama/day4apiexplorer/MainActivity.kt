package com.blendrama.day4apiexplorer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
