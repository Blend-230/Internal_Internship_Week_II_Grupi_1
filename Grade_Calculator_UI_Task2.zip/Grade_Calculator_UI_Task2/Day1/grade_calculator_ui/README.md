# Grade Calculator UI - Day 1 Task 2

Ky projekt është për **Internal Internship - Week II - Flutter App Development**, **Day 1 - Task 2**.

## Përshkrimi

Aplikacion i thjeshtë Flutter që merr tri nota numerike, validon inputet dhe llogarit mesataren me dy shifra pas presjes.

## Funksionalitetet kryesore

- Përdor `MaterialApp` dhe `Scaffold`.
- Përdor 3 `TextField` për vlera numerike.
- Validon që fushat nuk janë bosh.
- Validon që vlerat janë numra.
- Kontrollon që notat janë nga 1 deri në 5.
- Shfaq mesataren me `toStringAsFixed(2)`.
- Shfaq statusin:
  - `Kalon` nëse mesatarja është `>= 2.0`
  - `Duhet përmirësim` nëse mesatarja është `< 2.0`
- Përdor `Row`, `Column`, `Padding`, `Container` dhe butona.
- UI responsive për mobile dhe desktop me `ConstrainedBox`.
- Shfaq `SnackBar` kur ka gabim në input.

## Screenshot

![Screenshot](assets/screenshots/grade_calculator_ui_screenshot.png)

## Si të ekzekutohet

```bash
flutter pub get
flutter run
```

## Commit i kërkuar

```bash
git add .
git commit -m "day1 calculator ui"
git push
```
