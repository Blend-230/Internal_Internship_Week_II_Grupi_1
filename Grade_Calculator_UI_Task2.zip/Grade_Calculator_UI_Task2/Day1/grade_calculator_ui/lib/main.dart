import 'package:flutter/material.dart';

void main() {
  runApp(const GradeCalculatorApp());
}

class GradeCalculatorApp extends StatelessWidget {
  const GradeCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Grade Calculator UI',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        useMaterial3: true,
      ),
      home: const GradeCalculatorScreen(),
    );
  }
}

class GradeCalculatorScreen extends StatefulWidget {
  const GradeCalculatorScreen({super.key});

  @override
  State<GradeCalculatorScreen> createState() => _GradeCalculatorScreenState();
}

class _GradeCalculatorScreenState extends State<GradeCalculatorScreen> {
  final TextEditingController firstGradeController = TextEditingController();
  final TextEditingController secondGradeController = TextEditingController();
  final TextEditingController thirdGradeController = TextEditingController();

  String resultText = 'Vendos tri nota për të llogaritur mesataren.';
  String statusText = '';
  bool hasCalculated = false;
  bool hasPassed = false;

  @override
  void dispose() {
    firstGradeController.dispose();
    secondGradeController.dispose();
    thirdGradeController.dispose();
    super.dispose();
  }

  void calculateAverage() {
    final String firstValue = firstGradeController.text.trim();
    final String secondValue = secondGradeController.text.trim();
    final String thirdValue = thirdGradeController.text.trim();

    if (firstValue.isEmpty || secondValue.isEmpty || thirdValue.isEmpty) {
      showMessage('Ju lutem plotësoni të gjitha fushat.');
      return;
    }

    final double? firstGrade = double.tryParse(firstValue);
    final double? secondGrade = double.tryParse(secondValue);
    final double? thirdGrade = double.tryParse(thirdValue);

    if (firstGrade == null || secondGrade == null || thirdGrade == null) {
      showMessage('Vlerat duhet të jenë numra validë.');
      return;
    }

    if (!isValidGrade(firstGrade) || !isValidGrade(secondGrade) || !isValidGrade(thirdGrade)) {
      showMessage('Notat duhet të jenë nga 1 deri në 5.');
      return;
    }

    final double average = (firstGrade + secondGrade + thirdGrade) / 3;
    final bool passed = average >= 2.0;

    setState(() {
      hasCalculated = true;
      hasPassed = passed;
      resultText = 'Mesatarja: ${average.toStringAsFixed(2)}';
      statusText = passed ? 'Status: Kalon' : 'Status: Duhet përmirësim';
    });
  }

  bool isValidGrade(double grade) {
    return grade >= 1 && grade <= 5;
  }

  void clearFields() {
    firstGradeController.clear();
    secondGradeController.clear();
    thirdGradeController.clear();

    setState(() {
      hasCalculated = false;
      hasPassed = false;
      resultText = 'Vendos tri nota për të llogaritur mesataren.';
      statusText = '';
    });
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEFF6FF),
      appBar: AppBar(
        title: const Text('Grade Calculator UI'),
        centerTitle: true,
        backgroundColor: const Color(0xFF1D4ED8),
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(24),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.10),
                      blurRadius: 18,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.calculate_rounded,
                      size: 70,
                      color: Color(0xFF1D4ED8),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Llogaritja e Mesatares',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF111827),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Shkruaj tri nota nga 1 deri në 5 dhe kliko butonin për rezultat.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        color: Color(0xFF4B5563),
                      ),
                    ),
                    const SizedBox(height: 24),
                    buildGradeField(
                      controller: firstGradeController,
                      label: 'Nota 1',
                      icon: Icons.looks_one_rounded,
                    ),
                    const SizedBox(height: 14),
                    buildGradeField(
                      controller: secondGradeController,
                      label: 'Nota 2',
                      icon: Icons.looks_two_rounded,
                    ),
                    const SizedBox(height: 14),
                    buildGradeField(
                      controller: thirdGradeController,
                      label: 'Nota 3',
                      icon: Icons.looks_3_rounded,
                    ),
                    const SizedBox(height: 22),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: calculateAverage,
                            icon: const Icon(Icons.done_rounded),
                            label: const Text('Llogarit'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF1D4ED8),
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: clearFields,
                            icon: const Icon(Icons.refresh_rounded),
                            label: const Text('Pastro'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF1D4ED8),
                              padding: const EdgeInsets.symmetric(vertical: 15),
                              side: const BorderSide(color: Color(0xFF1D4ED8)),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 22),
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: hasCalculated
                            ? (hasPassed ? const Color(0xFFECFDF5) : const Color(0xFFFFF7ED))
                            : const Color(0xFFF3F4F6),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: hasCalculated
                              ? (hasPassed ? const Color(0xFF10B981) : const Color(0xFFF97316))
                              : const Color(0xFFE5E7EB),
                        ),
                      ),
                      child: Column(
                        children: [
                          Text(
                            resultText,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF111827),
                            ),
                          ),
                          if (statusText.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Text(
                              statusText,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.bold,
                                color: hasPassed ? const Color(0xFF047857) : const Color(0xFFC2410C),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildGradeField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
  }) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        hintText: 'Shembull: 5',
        prefixIcon: Icon(icon),
        filled: true,
        fillColor: const Color(0xFFF9FAFB),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }
}
