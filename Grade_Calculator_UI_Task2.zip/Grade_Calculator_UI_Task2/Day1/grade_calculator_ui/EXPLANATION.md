PJESËT KRYESORE TË ZGJIDHJES

1. main()
- E nis aplikacionin me runApp().

2. GradeCalculatorApp
- Përdor MaterialApp dhe cakton ekranin kryesor.

3. GradeCalculatorScreen
- Është StatefulWidget sepse rezultati ndryshon pasi përdoruesi klikon butonin.

4. TextEditingController
- Lexon vlerat nga tri fushat TextField.

5. calculateAverage()
- Kontrollon nëse fushat janë bosh.
- Kontrollon nëse vlerat janë numra.
- Kontrollon nëse notat janë nga 1 deri në 5.
- Llogarit mesataren.
- Shfaq rezultatin me dy shifra pas presjes.
- Vendos statusin Kalon ose Duhet përmirësim.

6. SnackBar
- Shfaq mesazh kur inputi nuk është valid.

7. Row dhe Column
- Column përdoret për organizim vertikal.
- Row përdoret për butonat Llogarit dhe Pastro.
