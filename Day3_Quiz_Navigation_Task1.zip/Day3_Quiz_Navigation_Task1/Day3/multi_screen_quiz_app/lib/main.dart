import 'package:flutter/material.dart';

void main() {
  runApp(const QuizApp());
}

class QuizApp extends StatelessWidget {
  const QuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Day 3 Quiz Navigation',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        useMaterial3: true,
      ),
      home: const QuizScreen(),
    );
  }
}

class QuizQuestion {
  final String questionText;
  final List<String> options;
  final int correctAnswerIndex;

  const QuizQuestion({
    required this.questionText,
    required this.options,
    required this.correctAnswerIndex,
  });
}

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int currentQuestionIndex = 0;
  int score = 0;

  final List<QuizQuestion> questions = const [
    QuizQuestion(
      questionText: 'Cila gjuhë përdoret kryesisht me Flutter?',
      options: ['Python', 'Dart', 'C++', 'PHP'],
      correctAnswerIndex: 1,
    ),
    QuizQuestion(
      questionText: 'Çka bën setState() në Flutter?',
      options: [
        'E fshin aplikacionin',
        'E rifreskon UI pas ndryshimit të të dhënave',
        'E hap GitHub-in',
        'E ndal aplikacionin',
      ],
      correctAnswerIndex: 1,
    ),
    QuizQuestion(
      questionText: 'Cila komandë përdoret për të hapur ekran të ri?',
      options: [
        'Navigator.pop()',
        'Navigator.push()',
        'setState()',
        'runApp()',
      ],
      correctAnswerIndex: 1,
    ),
    QuizQuestion(
      questionText: 'Çka është model class në Dart?',
      options: [
        'Klasë për organizimin e të dhënave',
        'Vetëm një ngjyrë',
        'Buton për klikim',
        'Një screenshot',
      ],
      correctAnswerIndex: 0,
    ),
    QuizQuestion(
      questionText: 'Çka bën Navigator.pop()?',
      options: [
        'Shton pikë',
        'Kthehet prapa nga ekrani aktual',
        'Krijon listë të re',
        'Ndryshon fontin',
      ],
      correctAnswerIndex: 1,
    ),
  ];

  void answerQuestion(int selectedIndex) {
    final currentQuestion = questions[currentQuestionIndex];
    final bool isCorrect = selectedIndex == currentQuestion.correctAnswerIndex;

    if (isCorrect) {
      score++;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(isCorrect ? 'Përgjigje e saktë!' : 'Përgjigje e gabuar!'),
        duration: const Duration(milliseconds: 600),
      ),
    );

    final bool isLastQuestion = currentQuestionIndex == questions.length - 1;

    if (isLastQuestion) {
      Future.delayed(const Duration(milliseconds: 650), () {
        if (!mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ResultScreen(
              score: score,
              totalQuestions: questions.length,
              onRestart: restartQuiz,
            ),
          ),
        );
      });
    } else {
      setState(() {
        currentQuestionIndex++;
      });
    }
  }

  void restartQuiz() {
    setState(() {
      currentQuestionIndex = 0;
      score = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final currentQuestion = questions[currentQuestionIndex];
    final double progress = (currentQuestionIndex + 1) / questions.length;

    return Scaffold(
      backgroundColor: const Color(0xFFF1F5F9),
      appBar: AppBar(
        title: const Text('Multi-screen Quiz App'),
        centerTitle: true,
        backgroundColor: const Color(0xFF2563EB),
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Card(
                elevation: 6,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        'Pyetja ${currentQuestionIndex + 1} nga ${questions.length}',
                        style: const TextStyle(
                          fontSize: 16,
                          color: Color(0xFF475569),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 10),
                      LinearProgressIndicator(
                        value: progress,
                        minHeight: 8,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        currentQuestion.questionText,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0F172A),
                        ),
                      ),
                      const SizedBox(height: 24),
                      ...List.generate(currentQuestion.options.length, (index) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: ElevatedButton(
                            onPressed: () => answerQuestion(index),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFEFF6FF),
                              foregroundColor: const Color(0xFF1D4ED8),
                              padding: const EdgeInsets.symmetric(
                                vertical: 16,
                                horizontal: 18,
                              ),
                              alignment: Alignment.centerLeft,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                            child: Text(
                              '${String.fromCharCode(65 + index)}) ${currentQuestion.options[index]}',
                              style: const TextStyle(fontSize: 16),
                            ),
                          ),
                        );
                      }),
                      const SizedBox(height: 10),
                      Text(
                        'Pikët aktuale: $score',
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF334155),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final int score;
  final int totalQuestions;
  final VoidCallback onRestart;

  const ResultScreen({
    super.key,
    required this.score,
    required this.totalQuestions,
    required this.onRestart,
  });

  String get resultMessage {
    final percentage = score / totalQuestions;
    if (percentage >= 0.8) return 'Shumë mirë!';
    if (percentage >= 0.5) return 'Mirë, por mund të përmirësohesh.';
    return 'Duhet më shumë ushtrim.';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF1F5F9),
      appBar: AppBar(
        title: const Text('Rezultati'),
        centerTitle: true,
        backgroundColor: const Color(0xFF2563EB),
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Card(
              elevation: 6,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(22),
              ),
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.emoji_events,
                      size: 80,
                      color: Color(0xFFF59E0B),
                    ),
                    const SizedBox(height: 18),
                    const Text(
                      'Quiz përfundoi!',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Rezultati yt: $score / $totalQuestions',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF2563EB),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      resultMessage,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 16,
                        color: Color(0xFF475569),
                      ),
                    ),
                    const SizedBox(height: 28),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton.icon(
                          onPressed: () {
                            onRestart();
                            Navigator.pop(context);
                          },
                          icon: const Icon(Icons.restart_alt),
                          label: const Text('Restart'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2563EB),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(
                              vertical: 14,
                              horizontal: 24,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        OutlinedButton.icon(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.arrow_back),
                          label: const Text('Kthehu'),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
