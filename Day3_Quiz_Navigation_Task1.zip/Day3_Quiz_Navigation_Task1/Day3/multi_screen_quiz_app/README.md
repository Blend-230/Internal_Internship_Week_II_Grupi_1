# Day 3 - Task 1: Multi-screen Quiz App

## Përshkrimi
Ky projekt është një Flutter quiz app me disa ekrane. Aplikacioni ka pyetje me opsione, ruan pikët me state, kalon në ekranin final me Navigator dhe ofron restart.

## Çka funksionon
- 5 pyetje me nga 4 opsione.
- State për pikët dhe pyetjen aktuale.
- `setState()` për rifreskim të UI-së.
- `Navigator.push()` për hapjen e ekranit të rezultatit.
- `Navigator.pop()` për kthim prapa/restart.
- `SnackBar` për feedback pas përgjigjes.
- UI responsive me `ConstrainedBox` për mobile dhe desktop.

## Çka mbetet për shtesë
- Shtimi i më shumë pyetjeve.
- Ruajtja e rezultateve në databazë.
- Ekran për review të përgjigjeve.
- Kategori të ndryshme quiz-i.

## Commit i kërkuar
```bash
git add .
git commit -m "day3 quiz navigation"
git push
```
