package com.blendrama.profilecardapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
