import 'package:flutter/material.dart';

void main() {
  runApp(const ProductCatalogApp());
}

class ProductCatalogApp extends StatelessWidget {
  const ProductCatalogApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Responsive Product Catalog',
      theme: ThemeData(primarySwatch: Colors.blueGrey),
      home: const ProductCatalogScreen(),
    );
  }
}

class Product {
  final String name;
  final String category;
  final double price;
  final IconData icon;

  Product({
    required this.name,
    required this.category,
    required this.price,
    required this.icon,
  });
}

class ProductCatalogScreen extends StatefulWidget {
  const ProductCatalogScreen({super.key});

  @override
  State<ProductCatalogScreen> createState() => _ProductCatalogScreenState();
}

class _ProductCatalogScreenState extends State<ProductCatalogScreen> {
  final TextEditingController searchController = TextEditingController();

  String selectedCategory = 'All';

  final List<Product> products = [
    Product(
        name: 'Laptop',
        category: 'Technology',
        price: 650.00,
        icon: Icons.laptop),
    Product(
        name: 'Phone',
        category: 'Technology',
        price: 399.99,
        icon: Icons.phone_android),
    Product(
        name: 'Headphones',
        category: 'Technology',
        price: 49.99,
        icon: Icons.headphones),
    Product(
        name: 'Backpack',
        category: 'School',
        price: 25.50,
        icon: Icons.backpack),
    Product(
        name: 'Notebook',
        category: 'School',
        price: 3.20,
        icon: Icons.menu_book),
    Product(
        name: 'Football',
        category: 'Sports',
        price: 18.00,
        icon: Icons.sports_soccer),
  ];

  List<Product> get filteredProducts {
    final searchText = searchController.text.toLowerCase();

    return products.where((product) {
      final matchesSearch = product.name.toLowerCase().contains(searchText);
      final matchesCategory =
          selectedCategory == 'All' || product.category == selectedCategory;

      return matchesSearch && matchesCategory;
    }).toList();
  }

  void updateSearch() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final productsToShow = filteredProducts;
    final screenWidth = MediaQuery.of(context).size.width;
    final isWideScreen = screenWidth > 600;

    return Scaffold(
      backgroundColor: Colors.blueGrey[50],
      appBar: AppBar(
        title: const Text('Product Catalog'),
        centerTitle: true,
        backgroundColor: Colors.blueGrey,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                TextField(
                  controller: searchController,
                  onChanged: (value) => updateSearch(),
                  decoration: const InputDecoration(
                    labelText: 'Search product by name',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedCategory,
                  decoration: const InputDecoration(
                    labelText: 'Filter by category',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.category),
                  ),
                  items: const [
                    DropdownMenuItem(value: 'All', child: Text('All')),
                    DropdownMenuItem(
                        value: 'Technology', child: Text('Technology')),
                    DropdownMenuItem(value: 'School', child: Text('School')),
                    DropdownMenuItem(value: 'Sports', child: Text('Sports')),
                  ],
                  onChanged: (value) {
                    setState(() {
                      selectedCategory = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: productsToShow.isEmpty
                      ? const Center(
                          child: Text(
                            'No products found.',
                            style: TextStyle(fontSize: 18),
                          ),
                        )
                      : isWideScreen
                          ? GridView.builder(
                              itemCount: productsToShow.length,
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                crossAxisSpacing: 12,
                                mainAxisSpacing: 12,
                                childAspectRatio: 1.2,
                              ),
                              itemBuilder: (context, index) {
                                return ProductCard(
                                    product: productsToShow[index]);
                              },
                            )
                          : ListView.builder(
                              itemCount: productsToShow.length,
                              itemBuilder: (context, index) {
                                return ProductCard(
                                    product: productsToShow[index]);
                              },
                            ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;

  const ProductCard({
    super.key,
    required this.product,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 28,
              backgroundColor: Colors.blueGrey,
              foregroundColor: Colors.white,
              child: Icon(product.icon, size: 30),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text('Category: ${product.category}'),
                  Text(
                    'Price: €${product.price.toStringAsFixed(2)}',
                    style: const TextStyle(
                      color: Colors.blueGrey,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
