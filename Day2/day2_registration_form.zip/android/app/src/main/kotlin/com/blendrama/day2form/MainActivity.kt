package com.blendrama.day2form

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
