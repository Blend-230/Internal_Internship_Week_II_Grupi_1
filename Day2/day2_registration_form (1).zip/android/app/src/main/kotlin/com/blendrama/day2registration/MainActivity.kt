package com.blendrama.day2registration

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
