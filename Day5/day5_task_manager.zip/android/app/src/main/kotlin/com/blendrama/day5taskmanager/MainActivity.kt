package com.blendrama.day5taskmanager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
