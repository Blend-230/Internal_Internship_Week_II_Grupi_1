package com.princlahi.profilecardapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
