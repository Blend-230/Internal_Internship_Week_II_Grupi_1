import 'package:flutter/material.dart';

void main() {
  runApp(const GradeCalculatorApp());
}

class GradeCalculatorApp extends StatelessWidget {
  const GradeCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Grade Calculator UI',
      home: const GradeCalculatorScreen(),
    );
  }
}

class GradeCalculatorScreen extends StatefulWidget {
  const GradeCalculatorScreen({super.key});

  @override
  State<GradeCalculatorScreen> createState() => _GradeCalculatorScreenState();
}

class _GradeCalculatorScreenState extends State<GradeCalculatorScreen> {
  final TextEditingController gradeOneController = TextEditingController();
  final TextEditingController gradeTwoController = TextEditingController();
  final TextEditingController gradeThreeController = TextEditingController();

  String resultText = 'Enter three grades to calculate the average.';
  String statusText = '';

  void calculateAverage() {
    String gradeOneText = gradeOneController.text;
    String gradeTwoText = gradeTwoController.text;
    String gradeThreeText = gradeThreeController.text;

    if (gradeOneText.isEmpty ||
        gradeTwoText.isEmpty ||
        gradeThreeText.isEmpty) {
      setState(() {
        resultText = 'Please fill in all fields.';
        statusText = '';
      });
      return;
    }

    double? gradeOne = double.tryParse(gradeOneText);
    double? gradeTwo = double.tryParse(gradeTwoText);
    double? gradeThree = double.tryParse(gradeThreeText);

    if (gradeOne == null || gradeTwo == null || gradeThree == null) {
      setState(() {
        resultText = 'Please enter only numbers.';
        statusText = '';
      });
      return;
    }

    double average = (gradeOne + gradeTwo + gradeThree) / 3;

    setState(() {
      resultText = 'Average: ${average.toStringAsFixed(2)}';

      if (average >= 2.0) {
        statusText = 'Status: Kalon';
      } else {
        statusText = 'Status: Duhet përmirësim';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[50],
      appBar: AppBar(
        title: const Text('Grade Calculator UI'),
        centerTitle: true,
        backgroundColor: Colors.blueGrey,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Container(
            width: 340,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              boxShadow: const [
                BoxShadow(
                  blurRadius: 8,
                  color: Colors.black26,
                  offset: Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.calculate,
                  size: 60,
                  color: Colors.blueGrey,
                ),
                const SizedBox(height: 15),
                const Text(
                  'Grade Average Calculator',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                const Text(
                  'Enter three grades or points to calculate the average.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: gradeOneController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'First grade',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: gradeTwoController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Second grade',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: gradeThreeController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Third grade',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: calculateAverage,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueGrey,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Calculate Average'),
                ),
                const SizedBox(height: 20),
                Text(
                  resultText,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  statusText,
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.blueGrey,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
