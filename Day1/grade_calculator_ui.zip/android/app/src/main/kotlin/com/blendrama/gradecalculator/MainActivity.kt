package com.blendrama.gradecalculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
