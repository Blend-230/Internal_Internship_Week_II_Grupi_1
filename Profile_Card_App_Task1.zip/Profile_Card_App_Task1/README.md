# Internal Internship - Week II - Flutter App Development

Folder structure:

- Day1/profile_card_app - Profile Card App completed for Task 1
- Day2
- Day3
- Day4
- Day5

Commit message for Task 1:

```bash
git commit -m "day1 profile card"
```
