# Profile Card App - Day 1 Task 1

Ky projekt është pjesë e Internal Internship - Week II - Flutter App Development.

## Përshkrimi

Aplikacioni prezanton një profil profesional me:

- Emër
- Rol
- Përshkrim të shkurtër
- Ikonë profili
- Informata kontakti
- Buton që ndryshon tekstin dhe shfaq SnackBar

## Kërkesat e plotësuara

- MaterialApp dhe Scaffold
- Text, Icon, Container, Row, Column, Padding
- Buton me SnackBar dhe ndryshim teksti
- Kod i organizuar me klasa dhe emra të qartë
- UI responsive për mobile dhe desktop

## Si të ekzekutohet

```bash
flutter pub get
flutter run
```

## Commit i kërkuar

```bash
git add .
git commit -m "day1 profile card"
git push
```

## Screenshot

Vendose screenshot-in e aplikacionit këtu pasi ta ekzekutosh.
